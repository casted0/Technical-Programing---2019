#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// Find all prime numbers untill a number n given by the user
// Optional: 
// Calculate also the sum of reciprocals of prime numbers
// less than n and reciprocals of twin primes less than n:

bool PrimeNumber(int N, vector<int> primes){

    int sqr_N = sqrt(N) + 1;

    for(vector<int>::size_type i = 0; primes[i]<sqr_N; i++){
        if(!(N % primes[i])){
            return false;
        }
    }

    return true;

}

int main(){

    vector<int> primes;
    int max_n;
    double reciprocal_sum = 0.0;
    double reciprocal_sum_twin = 0.0;

    do{

        cout << "Please, introduce a number higher than 2: ";
        cin >> max_n;

    }while(max_n < 3);

    primes.push_back(2);

    for(int i = 3; i < max_n; i++){

        if(PrimeNumber(i, primes)){
            primes.push_back(i);
        }

    }

    for(vector<int>::size_type i = 0; i < primes.size(); i++){
        cout << primes[i] << " " << endl;
    }

    for(vector<int>::size_type i = 0; i < primes.size(); i++){
        reciprocal_sum += (1/(double)primes[i]);
    }

    cout << "Reciprocal sum: " << reciprocal_sum << endl;

    for(vector<int>::size_type i = 0; i < primes.size()-2; i++){
        reciprocal_sum_twin += (1/(double)primes[i] + (1/(double)primes[i+2]));
    }

    cout << "Reciprocal sum of twins: " << reciprocal_sum_twin << endl;

    return 0;


}

// Fastest way to see if a number n is prime:
// Check if that number is divisible by any of the prime numbers that precede n square root