M=importdata('test_asc.dat', ' ', 2);
imagesc(M.data); 
colormap(gray);
axis square;
